#Studnet Name- Harsh Patel
#Student ID- 8913372

import psycopg2
from psycopg2.extras import RealDictCursor
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

# Database connection details
def get_db_connection():
    """
    Establishes a connection to the PostgreSQL database using the provided credentials.
    Returns the connection object.
    """
    conn = psycopg2.connect(
        host="ep-withered-river-a554dmdd-pooler.us-east-2.aws.neon.tech",
        dbname="neondb",
        user="neondb_owner",
        password="npg_7wYfJVQ1iAqe",
        sslmode="require"
    )
    return conn

def log_insert_to_ledger(item_name, category, quantity, price):
    """
    Logs an INSERT operation into the ledger table.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO ledger (operation_type, item_name, category, new_quantity, new_price)
        VALUES (%s, %s, %s, %s, %s)
    """, ('INSERT', item_name, category, quantity, price))
    conn.commit()
    cursor.close()
    conn.close()

def log_update_to_ledger(item_id, item_name, category, previous_quantity, new_quantity, previous_price, new_price):
    """
    Logs an UPDATE operation into the ledger table.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO ledger (operation_type, item_name, category, previous_quantity, new_quantity, previous_price, new_price)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, ('UPDATE', item_name, category, previous_quantity, new_quantity, previous_price, new_price))
    conn.commit()
    cursor.close()
    conn.close()

def log_delete_to_ledger(item_name, category, quantity, price):
    """
    Logs a DELETE operation into the ledger table.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO ledger (operation_type, item_name, category, previous_quantity, previous_price)
        VALUES (%s, %s, %s, %s, %s)
    """, ('DELETE', item_name, category, quantity, price))
    conn.commit()
    cursor.close()
    conn.close()

def add_item(name, category, quantity, price):
    """
    Adds a new item to the inventory table and logs the operation in the ledger.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO inventory (name, category, quantity, price)
        VALUES (%s, %s, %s, %s)
    """, (name, category, quantity, price))
    conn.commit()
    cursor.close()
    conn.close()

    log_insert_to_ledger(name, category, quantity, price)

def update_item(item_id, new_name, new_category, new_quantity, new_price):
    """
    Updates an existing item in the inventory table and logs the operation in the ledger.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM inventory WHERE id = %s", (item_id,))
    item = cursor.fetchone()
    if item is None:
        raise ValueError("Item ID does not exist.")
    
    previous_quantity = item[3] 
    previous_price = item[4]     
    item_name = item[1]          
    category = item[2]           

    cursor.execute("""
        UPDATE inventory
        SET name = %s, category = %s, quantity = %s, price = %s
        WHERE id = %s
    """, (new_name, new_category, new_quantity, new_price, item_id))
    conn.commit()
    cursor.close()
    conn.close()

    log_update_to_ledger(item_id, item_name, category, previous_quantity, new_quantity, previous_price, new_price)

def delete_item(item_id):
    """
    Deletes an item from the inventory table and logs the operation in the ledger.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM inventory WHERE id = %s", (item_id,))
    item = cursor.fetchone()
    if item is None:
        raise ValueError("Item ID does not exist.")
    
    item_name = item[1]
    category = item[2]
    quantity = item[3]
    price = item[4]

    cursor.execute("DELETE FROM inventory WHERE id = %s", (item_id,))
    conn.commit()
    cursor.close()
    conn.close()

    log_delete_to_ledger(item_name, category, quantity, price)


root = tk.Tk()
root.title("Inventory Management")
root.geometry("800x500")

item_id_entry = tk.Entry(root)
item_id_entry.grid(row=0, column=1, padx=10, pady=10)
item_id_label = tk.Label(root, text="Item ID")
item_id_label.grid(row=0, column=0, padx=10, pady=10)

name_entry = tk.Entry(root)
name_entry.grid(row=1, column=1, padx=10, pady=10)
name_label = tk.Label(root, text="Item Name")
name_label.grid(row=1, column=0, padx=10, pady=10)

category_entry = tk.Entry(root)
category_entry.grid(row=2, column=1, padx=10, pady=10)
category_label = tk.Label(root, text="Category")
category_label.grid(row=2, column=0, padx=10, pady=10)

quantity_entry = tk.Entry(root)
quantity_entry.grid(row=3, column=1, padx=10, pady=10)
quantity_label = tk.Label(root, text="Quantity")
quantity_label.grid(row=3, column=0, padx=10, pady=10)

price_entry = tk.Entry(root)
price_entry.grid(row=4, column=1, padx=10, pady=10)
price_label = tk.Label(root, text="Price")
price_label.grid(row=4, column=0, padx=10, pady=10)

# Inventory table
columns = ("ID", "Name", "Category", "Quantity", "Price")
inventory_tree = ttk.Treeview(root, columns=columns, show="headings")

for col in columns:
    inventory_tree.heading(col, text=col)

inventory_tree.grid(row=5, column=0, columnspan=4, padx=10, pady=10)

def update_table():
    """
    Updates the inventory table in the UI with the latest data from the database.
    """
    for row in inventory_tree.get_children():
        inventory_tree.delete(row)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM inventory")
    items = cursor.fetchall()
    for item in items:
        inventory_tree.insert("", "end", values=item)
    cursor.close()
    conn.close()

# Add button
def on_add_item():
    """
    Handles the "Add Item" button click event.
    Validates input fields and adds a new item to the inventory.
    """
    try:
        name = name_entry.get()
        category = category_entry.get()

        try:
            quantity = int(quantity_entry.get())
        except ValueError:
            raise ValueError("Please enter a valid number for Quantity.")
        
        try:
            price = float(price_entry.get())
        except ValueError:
            raise ValueError("Please enter a valid number for Price.")
        
        if not name or not category:
            raise ValueError("Please fill in all fields correctly.")
        
        add_item(name, category, quantity, price)
 
        update_table()
        
        name_entry.delete(0, tk.END)
        category_entry.delete(0, tk.END)
        quantity_entry.delete(0, tk.END)
        price_entry.delete(0, tk.END)
        
        messagebox.showinfo("Success", "Item added successfully!")
    except ValueError as e:
        messagebox.showerror("Error", str(e))

add_button = tk.Button(root, text="Add Item", command=on_add_item)
add_button.grid(row=6, column=0, padx=10, pady=10)

# Update button
def on_update_item():
    """
    Handles the "Update Item" button click event.
    Validates input fields and updates an existing item in the inventory.
    """
    try:
        item_id = item_id_entry.get()

        if not item_id.isdigit():
            raise ValueError("Please Enter a valid Item ID.")
        item_id = int(item_id)
        
        name = name_entry.get()
        category = category_entry.get()
        
        try:
            quantity = int(quantity_entry.get())
        except ValueError:
            raise ValueError("Please enter a valid number for Quantity.")
        
        try:
            price = float(price_entry.get())
        except ValueError:
            raise ValueError("Please enter a valid number for Price.")
        
        if not name or not category:
            raise ValueError("Please enter all fields correctly.")
        
        update_item(item_id, name, category, quantity, price)
        
        update_table()
        
        name_entry.delete(0, tk.END)
        category_entry.delete(0, tk.END)
        quantity_entry.delete(0, tk.END)
        price_entry.delete(0, tk.END)
        
        messagebox.showinfo("Success", "Item updated successfully!")
    except ValueError as e:
        messagebox.showerror("Error", str(e))

update_button = tk.Button(root, text="Update Item", command=on_update_item)
update_button.grid(row=6, column=1, padx=10, pady=10)

# Delete button
def on_delete_item():
    """
    Handles the "Delete Item" button click event.
    Validates input fields and deletes an item from the inventory.
    """
    try:
        item_id = item_id_entry.get()
        
        if not item_id.isdigit():
            raise ValueError("Please enter a valid Item ID.")
        item_id = int(item_id)

        delete_item(item_id)

        update_table()

        item_id_entry.delete(0, tk.END)
        messagebox.showinfo("Success", "Item deleted successfully!")
    except ValueError as e:
        messagebox.showerror("Error", str(e))

delete_button = tk.Button(root, text="Delete Item", command=on_delete_item)
delete_button.grid(row=6, column=2, padx=10, pady=10)

# Ledger button
def display_ledger():
    """
    Displays the ledger history in a new window.
    """
    ledger_window = tk.Toplevel(root)
    ledger_window.title("Ledger History")
    
    ledger_tree = ttk.Treeview(ledger_window, columns=("Timestamp", "Operation", "Item Name", "Category", "Previous Quantity", "New Quantity", "Previous Price", "New Price"), show="headings")
    
    for col in ledger_tree["columns"]:
        ledger_tree.heading(col, text=col)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ledger ORDER BY timestamp DESC")
    ledger_entries = cursor.fetchall()
    cursor.close()
    conn.close()

    for entry in ledger_entries:
        ledger_tree.insert("", tk.END, values=entry)
    
    ledger_tree.pack(fill=tk.BOTH, expand=True)

ledger_button = tk.Button(root, text="Show Ledger", command=display_ledger)
ledger_button.grid(row=6, column=3, padx=10, pady=10)

root.mainloop()